<?php
$host = 'localhost';
$db   = 'eqe_inventory_tracking';
$user = 'root';
$pass = ''; // В XAMPP по подразбиране е празно

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("Грешка при връзка с базата данни: " . $e->getMessage());
}
?>